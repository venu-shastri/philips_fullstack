This example shows a comparison between event emitter and callbacks.

To run the example launch:

  node test
