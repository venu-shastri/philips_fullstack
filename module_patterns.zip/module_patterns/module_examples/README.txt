These examples shows different ways to expose functionality through module pattern.

To run the examples launch files ending with *_test.js:

  node <filename>_test

Real modules are stored files without the "_test" suffix
