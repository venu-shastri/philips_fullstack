This sample demonstrates what happens when there are cycles in module
dependencies.

  node main
