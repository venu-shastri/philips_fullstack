const hello='hello';
function loadModule(filename, module, require) {
    const wrappedSrc =
      `(function(module, exports, require) {
        ${hello}
      })(module, module.exports, require);`;
    eval(wrappedSrc);
  }
  
  function test(){
  const module = {               
    exports: {},
    id: "test.txt"
  };


  loadModule("test,txt",module,require);

  console.log(module.exports);
}

test();