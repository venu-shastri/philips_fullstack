"use strict";

exports.log = () => {
  console.log("From module B: the homemade require works!");
};
