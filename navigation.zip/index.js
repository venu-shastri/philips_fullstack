import { AppRegistry } from 'react-native';
import App from './App';

console.ignoredYellowBox = ['Warning', 'Remote']

AppRegistry.registerComponent('CitiesApp', () => App);
