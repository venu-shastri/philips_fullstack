import React from 'react';

const ThemeContext = React.createContext(null); // could use 'green' as initial value here as well

export default ThemeContext;