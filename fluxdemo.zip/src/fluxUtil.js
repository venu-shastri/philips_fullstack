import Dispatcher from './dispatcher'
import MicroEvent from './microevent'
var  FluxUtil=(function(){

var _appDispatcher=new Dispatcher();

return {
    AppDispatcher:_appDispatcher,
    getObservableStore:function(store){
        return MicroEvent.mixin(store);
    }

}


})();

export default FluxUtil;
