import FluxUtil from './fluxUtil';

function ListStore(){
    var self= FluxUtil.getObservableStore(this);
    this.items=[];
    this.getCurrentItems=function(){
        return this.items;
    }
    this.addNewItem=function(item){
        this.items.push(item);
    }
    this.handleDiapatcherAction=function(actionObj){

        switch(actionObj.actionName){
                case "NEW_ITEM":
                    self.addNewItem(actionObj.actionData)
                    self.trigger("onNewItemCreated");
                break;
        }
    }
}
var ListStoreInstance=new  ListStore();
FluxUtil.AppDispatcher.register(ListStoreInstance.handleDiapatcherAction);
export default ListStoreInstance;



