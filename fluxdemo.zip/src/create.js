import React,{Component} from 'react'
import FluxUtil from './fluxUtil'

export class CreateComponent extends Component{

    _itemCode;
    _itemName;

    constructor(props){
        super(props);
        this.handleItemCodeTextChange=this.handleItemCodeTextChange.bind(this);
        this.handleItemNameTextChange=this.handleItemNameTextChange.bind(this);
        this.handleAddNewItemClick=this.handleAddNewItemClick.bind(this);
        this.handleClearClick=this.handleClearClick.bind(this);
    }
    handleItemCodeTextChange(e){
        this._itemCode=e.target.value;
    }
    handleItemNameTextChange(e){
        this._itemName=e.target.value;
    }
    handleAddNewItemClick(e){
        
        //Dispatch - Action- NEW_ITEM
        let action={actionName:"NEW_ITEM",
                    actionData:{ 
                        itemCode:this._itemCode,
                        itemName:this._itemName
                    }
                 }
        FluxUtil.AppDispatcher.dispatch(action);
        console.log(action);
    }
    handleClearClick(e){
        
    }
    render(){
        return(
            <table>
                <tr>
                    <td>Item Code </td>
                    <td> <input type="text" onChange={this.handleItemCodeTextChange} /></td>
                </tr>
                <tr>
                    <td>Item Name </td>
                    <td> <input type="text" onChange={this.handleItemNameTextChange} /></td>
                </tr>
                
                <tr>
                    <td> <button onClick={this.handleAddNewItemClick}>AddNewItem</button> </td>
                    <td> <button onClick={this.handleClearClick}>Clear</button> </td>
                </tr>
               </table> 

                    

        );
    }
}