import React,{Component} from 'react'
export class ItemRowComponent extends Component{

    render(){
        return (

            <tr>
                <td>{this.props.Item.itemCode}</td>
                <td>{this.props.Item.itemName}</td>
            </tr>
        );
    }
}
