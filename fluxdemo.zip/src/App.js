import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { CreateComponent} from './create'
import {DisplayComponent} from './display'
class App extends Component {
  render() {
    return (
      <div className="App">
       <CreateComponent/>
       <DisplayComponent/>
      </div>
    );
  }
}

export default App;
