import React,{Component} from 'react'
import ListStoreInstance from './itemStore'
import {ItemRowComponent} from './itemRow'
export class DisplayComponent extends Component{

    
    constructor(props){
        super(props);
        this.state={items:[]};

        this.handleOnNewItemAdded=this.handleOnNewItemAdded.bind(this);

ListStoreInstance.bind('onNewItemCreated',this.handleOnNewItemAdded);
}

handleOnNewItemAdded(){
  //  console.log(ListStoreInstance.getCurrentItems());
   this.setState({items:ListStoreInstance.getCurrentItems()});
console.log("Diplay View Notified  " + this.state.items);

}
    render(){


        var rows=[];
        console.log(this.state.items);
        this.state.items.forEach((item)=>{

            rows.push(<ItemRowComponent Item={item} key={item.itemCode}/>);

        });
        return(

            <table>
                <thead>
                    <tr>
                        <th>ItemCode</th>
                        <th>ItemName</th>
                        </tr>
                        </thead>
                        <tbody>{rows}</tbody>
                        </table>
        );
    }
}