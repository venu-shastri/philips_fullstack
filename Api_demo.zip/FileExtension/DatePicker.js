import React from 'react'
import DatePicker from './DatePicker’

const MainComponent = () => (
  <View>
    <DatePicker />
  </View>
)
