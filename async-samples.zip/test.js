async function search(key){

    //returns Proise Object
    //return new Promise((resolve,reject)=>{

        //resolve("hello " +key );
    //});
    return  await  "hello " + key;
}

var result=search("asdsa");

result.then(result=>{

    console.log(result);

});
