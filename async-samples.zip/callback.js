var cities = ['Tokyo', 
'London', 'Boston', 'Berlin', 'Chicago', 'New York'];
cities.forEach(function callback(city) {
console.log(city);
});